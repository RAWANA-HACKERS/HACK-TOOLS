# Ransomware & Cryptography : Virtual Gangster
<p align="center">
  <img src="https://cdn0.iconfinder.com/data/icons/cyber-crime-or-threats-blue-set/120/hacker_cyber_crime-256.png">
</p>

# Scripts
* [CryPy_Source](https://github.com/roothaxor/Ransom/blob/master/CryPy_Source.py)	: Used in wild .crypy ransomware written in python, full source code
* [batch_ransom_example.txt](https://github.com/roothaxor/Ransom/blob/master/batch_ransom_example.txt) : Proof, ransomware can be coded in batch programming
* [c2serverlist.txt](https://github.com/roothaxor/Ransom/blob/master/c2serverlist.txt) : C2 servers list distributing the ransomwares in wild update on 1/08/2016
* [decrypter.c](https://github.com/roothaxor/Ransom/blob/master/decrypter.c) : Decryption program for AES256_CBC Encryption, Written in C
* [encrpter.c](https://github.com/roothaxor/Ransom/blob/master/encrypter.c) : Encryption program Using AES256 with CBC cipher mode, Written in C
* [holycrypt-v0.3.py](https://github.com/roothaxor/Ransom/blob/master/holycrypt-v0.3.py) : Holycrypt Ransomware Source code, Dont run this if dont know what it is

### This is not only for educational purpose Criminals are invited to Use it Bad Way. Just Kidding
